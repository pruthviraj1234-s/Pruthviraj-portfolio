SIMPLE PROFESSIONAL PORTFOLIO
=============================

FILES
- index.html  : portfolio content and page structure
- style.css   : colors, layout, responsive design
- script.js   : mobile navigation and current year

HOW TO OPEN
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html to open it in your browser.
4. Internet is only needed for the optional Google Fonts; the page works without them.

PERSONALIZE BEFORE SHARING
- Replace "Your Name" and "YN" with your own name/initials.
- Update your email address, city, GitHub, and LinkedIn links.
- Update the education details.
- Keep only projects you have actually built and edit their descriptions accordingly.

Note: "Java" and "JavaScript" are different languages. This website uses JavaScript, as requested for an HTML/CSS portfolio website.
